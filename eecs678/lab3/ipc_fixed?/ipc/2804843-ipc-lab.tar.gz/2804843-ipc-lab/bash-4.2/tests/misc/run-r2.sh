../../bash ./redir-t2.sh < /etc/passwd
